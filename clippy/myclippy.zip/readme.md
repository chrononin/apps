                                             ⒸⓁⒾⓅⓅⓎ

CLIPPY is a single page clipboard manager app based on offline browser based storage session.
You can organise any password or any other character strings which require to copy and paste from multiple times in daily basis, 
some times keeping multiple passwrod or access token keep in mind is tedious job and there are security restriction as well. 
you can use in such scenarios as this app will  not display password but will allow you copy in single click. 
and you can import as plain text or encrypted format. so you can use that later.

more can be found here - https://m.chronon.in/main/clippy/about_clippy

CLIPPY doesn't store anything over internet. all the data stored by clippy app is to local to that internet browser only. 

To access the online version of clippy please visit - [https://m.chronon.in/main/clippy/myclippy]

Steps to use the clippy - graphics are available on - [https://m.chronon.in/main/clippy/howtouse]

1. Download the myclippy.html and open it in the browser. - [https://github.com/chrononin/apps/blob/main/clippy/myclippy.html]
2. if you wanna use a existing clippy sample download the clippy.zip and unzip it.
3. two clippy file present for the password protected one - password is 'password'.
4. Enjoy!

a. Initialise clippy.
b. import existing clippy.
c. change the owner name
d. change the clippy file name
e. Save the clippy in local browser storage
f. Clear the clippy from saved /loaded details to re initialise or re import or to clean up the browser saved content.
g. export the saved clippy information.
h. explore & enjoy!



